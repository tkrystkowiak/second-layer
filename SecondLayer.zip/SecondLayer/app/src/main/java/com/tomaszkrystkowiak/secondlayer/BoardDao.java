package com.tomaszkrystkowiak.secondlayer;

import androidx.room.Dao;

@Dao
public interface BoardDao {
}
